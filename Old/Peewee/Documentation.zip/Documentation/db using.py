from peewee import *
from db_formatting import Person, Pet
db = SqliteDatabase('people.db')

for person in Person.select():
    print(person.name)

query = Pet.select().where(Pet.animal_type == 'cat')
for pet in query:
    print(pet.name, pet.owner.name)
